/* Cookies Directive Disclosure Script
* Version: 1.2
* Author: Ollie Phillips
* Modified: Ruben Gonzalez, July 2013
* Copyright: Copyright (C) 2011 by Ollie Phillips
*/
/*var script = document.createElement('script');
script.src = 'jquery-1.10.2.min.js';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);*/

var pageprivacy = location.protocol + "//" + location.host + "/privacy";
var serviceUrl = location.protocol + "//" + "eucookie.xh1.lilly.com/services/AlertCookies.svc/";
var serviceUrlGet = location.protocol + "//" + "eucookie.xh1.lilly.com/services/AlertCookiesGet.svc/";
var serviceBanner = "GetBanner";
var serviceSettings = "GetSettings";
var serviceCookieList = "GetCookie";
var urlCss = "./css/EUCookiesStylesheet.css"
var cookiesStaticWhiteList = ["style", "I18N_LANGUAGE", "_ZopeId", "__ac", "__ac_username", "__ac_persistent", "areYourCookiesEnabled", "protected_auth", "JSESSIONID", "BIGipServercmg-sites-8", "ASP.NET_SessionId", "BIGipServercmg-sites-3", "self_validated_hcp","AWSELB"];
var my_jQuery;
// http://172.17.12.13/EUCookiesDirective
// http://87.216.51.75/EUCookiesDirective
// http://localhost:1064
function cookiesDirective(siteId, language) {
    // From v1.1 the position can be set to 'top' or 'bottom' of viewport
    var disclosurePosition = 'top';
    var cookieScripts;
    // Start Test/Loader (improved in v1.1)
    // var jQueryVersion = '1.5';
    var jQueryVersion = '1.10.2';
    
    var s = document.createElement("script");
    //s.src = location.protocol + "//ajax.googleapis.com/ajax/libs/jquery/" + jQueryVersion + "/jquery.min.js";
	s.src = location.protocol + "//eucookie.xh1.lilly.com/Scripts/jquery.min.js";
    s.type = "text/javascript";
    s.onload = s.onreadystatechange = function () {
        if ((!s.readyState || s.readyState == "loaded" || s.readyState == "complete")) {

            my_jQuery = jQuery.noConflict(false);

            if (!cdReadCookie('cookiesDirective')) {
                if (!cdReadCookie('cookiesDirectiveSession')) {
                    getHtml(disclosurePosition, siteId, language, serviceBanner);
                    jaaulde.utils.cookies.del(true);
                    cdCreateCookie('cookiesDirectiveSession', 1);
                } else
                    cdCreateCookie('cookiesDirective', 1, 730);
            } else {

                if (cdReadCookie('cookiesDirective') != '1') cdWhitelistHandler(siteId);
            }
        }
    }
    document.getElementsByTagName("head")[0].appendChild(s);
}
function cookiesDirectiveExplicit(siteId, language) {
    // From v1.1 the position can be set to 'top' or 'bottom' of viewport
    var disclosurePosition = 'top';
    var cookieScripts;
    // Start Test/Loader (improved in v1.1)
    // var jQueryVersion = '1.5';
    var jQueryVersion = '1.10.2';

    var s = document.createElement("script");
    s.src = location.protocol + "//ajax.googleapis.com/ajax/libs/jquery/" + jQueryVersion + "/jquery.min.js";
    s.type = "text/javascript";
    s.onload = s.onreadystatechange = function () {
        if ((!s.readyState || s.readyState == "loaded" || s.readyState == "complete")) {

            my_jQuery = jQuery.noConflict(false);

            if (!cdReadCookie('cookiesDirective')) {
                getHtml(disclosurePosition, siteId, language, serviceBanner);
                jaaulde.utils.cookies.del(true);

            } else {

                if (cdReadCookie('cookiesDirective') != '1') cdWhitelistHandler(siteId);
            }
        }
    }
    document.getElementsByTagName("head")[0].appendChild(s);

}

function acceptExplictConsent() {
    cdCreateCookie('cookiesDirective', 1, 730);
    my_jQuery("#epd").slideUp("slow");
}
function cdWhitelistHandler(siteId) {
    //call whitelist cookies
    var levels = cdReadCookie('cookiesDirective');
    levels = levels.replace(/,/g, ";")

    if ((navigator.userAgent.indexOf('MSIE') != -1 && parseInt(navigator.userAgent.substr(navigator.userAgent.indexOf('MSIE') + 5, 1)) > 1) ||
    (navigator.userAgent.indexOf('rv') != -1 && parseInt(navigator.userAgent.substr(navigator.userAgent.indexOf('rv') + 3, 2)) > 1))
    {
        my_jQuery.ajax({
            type: "GET",
            url: serviceUrlGet + serviceCookieList + "?idsite=" + siteId + "&levels=" + levels + "&callback=?",
            jsonpCallback: 'jsonCallback',
            contentType: "application/javascript",
            dataType: 'jsonp',
            success: function (mensaje) {
                cookiesWhiteList = response.GetCookieResult;
                clearCookiesHandler(cookiesWhiteList);
            },
            error: function (err) {
                //alert("error:" + err.status + ", " + err.statusText);

            }
        });
    }
    else {
        my_jQuery.ajax({
            type: "POST",
            url: serviceUrl + serviceCookieList,
            data: '{' + '"idsite":"' + siteId + '", "levels":"' + levels + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                cookiesWhiteList = response.GetCookieResult;
                clearCookiesHandler(cookiesWhiteList);
            },
            error: function (err) {
                //alert("error:" + err.status + ", " + err.statusText);

            }
        });
    }
}
function clearCookiesHandler(cookiesWhiteList) {
    var epdApps;
    var epdAppsCount;
    var blackList = new Array();
    // What scripts must be declared, user passes these as comma delimited string
    if (cookiesWhiteList) {
        epdApps = cookiesWhiteList.split(',');
        epdAppsCount = epdApps.length;
        var epdAppsDisclosureText = '';
        blackList = jaaulde.utils.cookies.get();
        if (epdAppsCount > 0) {
            for (var t = 0; t < epdAppsCount; t++) {
                //create black list cookies
                var cookies2 = jaaulde.utils.cookies.get(epdApps[t]);
                if (cookies2) delete blackList[epdApps[t]];
            }

            for (var name in blackList) {
                jaaulde.utils.cookies.del(name);
            }
        }
    } else {
        //remove all cookies
        jaaulde.utils.cookies.del(true);
    }
    //remove black cookies

}
function getHtml(disclosurePosition, siteId, language, service) {
    my_jQuery.support.cors = true;

    if ((navigator.userAgent.indexOf('MSIE') != -1 && parseInt(navigator.userAgent.substr(navigator.userAgent.indexOf('MSIE') + 5, 1)) > 1) || 
    (navigator.userAgent.indexOf('rv') != -1 && parseInt(navigator.userAgent.substr(navigator.userAgent.indexOf('rv') + 3, 2)) > 1))
    {
        my_jQuery.ajax({
            type: "GET",
            url: serviceUrlGet + service + "?idsite=" + siteId + "&language=" + language + "&callback=?",
            jsonpCallback: 'jsonCallback',
            contentType: "application/javascript",
            dataType: 'jsonp',
            success: function (mensaje) {
                if (service == serviceBanner)
                    cdHandler(disclosurePosition, siteId, mensaje.GetBannerResult.Html, mensaje.GetBannerResult.Css);
                else if (service == serviceSettings)
                    displaySettings(disclosurePosition, siteId, mensaje.GetSettingsResult.Html, mensaje.GetSettingsResult.Css);
            },
            error: function (err) {
                //alert("error:" + err.status + ", " + err.statusText);

            }
        });
    }
    else {
        my_jQuery.ajax({
            type: "POST",
            url: serviceUrl + service,
            data: '{' + '"idsite":"' + siteId + '", "language":"' + language + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (mensaje) {
                if (service == serviceBanner)
                    cdHandler(disclosurePosition, siteId, mensaje.GetBannerResult.Html, mensaje.GetBannerResult.Css);
                else if (service == serviceSettings)
                    displaySettings(disclosurePosition, siteId, mensaje.GetSettingsResult.Html, mensaje.GetSettingsResult.Css);
            },
            error: function (err) {
                //alert("error:" + err.status + ", " + err.statusText);

            }
        });

    }



    //HTML retrieved,will be used for displaying the banner.

}

function cdHandler(disclosurePosition, siteId, html, css) {
    // Our main disclosure script
    my_jQuery(document).ready(function () {
        // Safe to proceed, Call Webservice
        if (my_jQuery("#cookiesdirective").length == 0) {
            my_jQuery('head').append(css);
            var epdAppsDisclosure;
            var epdDisclosurePosition;
            epdDisclosurePosition = disclosurePosition;
            // Create our overlay with message
            var divNode = document.createElement('div');
            divNode.setAttribute('id', 'epd');
            divNode.setAttribute('style', 'display: none;');
            document.body.insertBefore(divNode, document.body.firstChild);
            //document.body.appendChild(divNode);
            var disclosure;
            document.getElementById("epd").innerHTML = html;
            my_jQuery("#epd").slideDown("slow");
            //my_jQuery("#cookiesdirective").hide();
            //alert(window.location.hostname);
            //my_jQuery("#cookiesdirective").hide();
            //my_jQuery("#cookiesdirective").slideDown("slow");
        }
    });
}
//Function for new cookie Settings page
function displaySettings(disclosurePosition, siteId, html, css) {
    // Our main disclosure script
    my_jQuery(document).ready(function () {
        my_jQuery('head').append(css);
        var epdAppsDisclosure;
        var epdDisclosurePosition;
        epdDisclosurePosition = disclosurePosition;
        // Create our overlay with message
        var divNode = document.createElement('div');
        divNode.setAttribute('id', 'epd');
        divNode.setAttribute('style', 'display: none;');
        document.body.insertBefore(divNode, document.body.firstChild);
        //document.body.appendChild(divNode);
        var disclosure;
        document.getElementById("epd").innerHTML = html;
        my_jQuery("#epd").slideDown("fast");
        my_jQuery("#savesettings").click(settingsButtonAction);
        settingsSetUpRadioButtons();
    });
}

function settingsSetUpRadioButtons() {
    var cookie = cdReadCookie('cookiesDirective');
    var i = 2;
    if (!cdReadCookie('cookiesDirective') || cookie == '1') {//There are no stored preferences, all radios to "enabled"
        while (my_jQuery('#level' + i + '_on').length > 0) {
            my_jQuery('#level' + i + '_on').attr('checked', 'checked');
            i++;
        }
    }
    else {//There are stored preferences, radios set up according to them
        var settingsPreferences = cookie.split(',');
        while (my_jQuery('#level' + i + '_on').length > 0) {
            if (settingsPreferences[i - 2] == 0)
                my_jQuery('#level' + i + '_off').attr('checked', 'checked');
            else if (settingsPreferences[i - 2] == 1)
                my_jQuery('#level' + i + '_on').attr('checked', 'checked');
            i++;
        }
    }
}


function settingsButtonAction() {
    // executed when saving new cookie settings
    var i = 2;
    var settingsCookie = '';
    while (my_jQuery('#level' + i + '_on').length > 0) {
        settingsCookie = settingsCookie + my_jQuery('input[name=level' + i + ']:checked', '#optout').val() + ',';
        i++;
    }
    settingsCookie = settingsCookie.substring(0, settingsCookie.length - 1);
    cdCreateCookie('cookiesDirective', settingsCookie, 730);
}

//COOKIE MANAGEMENT FROM HERE

// Simple Cookie functions from http://www.quirksmode.org/js/cookies.html - thanks!
function cdReadCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}
function cdCreateCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    }
    else var expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}
/*******************************************/
/**
* Copyright (c) 2005 - 2010, James Auldridge
* All rights reserved.
*
* Licensed under the BSD, MIT, and GPL (your choice!) Licenses:
* http://code.google.com/p/cookies/wiki/License
*
*/
var jaaulde = window.jaaulde || {};
jaaulde.utils = jaaulde.utils || {};
jaaulde.utils.cookies = (function () {
    var resolveOptions, assembleOptionsString, parseCookies, constructor, defaultOptions = {
        expiresAt: null,
        path: '/',
        domain: null,
        secure: false
    };
    /**
    * resolveOptions - receive an options object and ensure all options are present and valid, replacing with defaults where necessary
    *
    * @access private
    * @static
    * @parameter Object options - optional options to start with
    * @return Object complete and valid options object
    */
    resolveOptions = function (options) {
        var returnValue, expireDate;
        if (typeof options !== 'object' || options === null) {
            returnValue = defaultOptions;
        }
        else {
            returnValue = {
                expiresAt: defaultOptions.expiresAt,
                path: defaultOptions.path,
                domain: defaultOptions.domain,
                secure: defaultOptions.secure
            };
            if (typeof options.expiresAt === 'object' && options.expiresAt instanceof Date) {
                returnValue.expiresAt = options.expiresAt;
            }
            else if (typeof options.hoursToLive === 'number' && options.hoursToLive !== 0) {
                expireDate = new Date();
                expireDate.setTime(expireDate.getTime() + (options.hoursToLive * 60 * 60 * 1000));
                returnValue.expiresAt = expireDate;
            }
            if (typeof options.path === 'string' && options.path !== '') {
                returnValue.path = options.path;
            }
            if (typeof options.domain === 'string' && options.domain !== '') {
                returnValue.domain = options.domain;
            }
            if (options.secure === true) {
                returnValue.secure = options.secure;
            }
        }
        return returnValue;
    };
    /**
    * assembleOptionsString - analyze options and assemble appropriate string for setting a cookie with those options
    *
    * @access private
    * @static
    * @parameter options OBJECT - optional options to start with
    * @return STRING - complete and valid cookie setting options
    */
    assembleOptionsString = function (options) {
        options = resolveOptions(options);
        return (
(typeof options.expiresAt === 'object' && options.expiresAt instanceof Date ? '; expires=' + options.expiresAt.toGMTString() : '') +
'; path=' + options.path +
(typeof options.domain === 'string' ? '; domain=' + options.domain : '') +
(options.secure === true ? '; secure' : '')
);
    };
    /**
    * parseCookies - retrieve document.cookie string and break it into a hash with values decoded and unserialized
    *
    * @access private
    * @static
    * @return OBJECT - hash of cookies from document.cookie
    */
    parseCookies = function () {
        var cookies = {}, i, pair, name, value, separated = document.cookie.split(';'), unparsedValue;
        for (i = 0; i < separated.length; i = i + 1) {
            pair = separated[i].split('=');
            name = pair[0].replace(/^\s*/, '').replace(/\s*$/, '');
            try {
                value = decodeURIComponent(pair[1]);
            }
            catch (e1) {
                value = pair[1];
            }
            if (typeof JSON === 'object' && JSON !== null && typeof JSON.parse === 'function') {
                try {
                    unparsedValue = value;
                    value = JSON.parse(value);
                }
                catch (e2) {
                    value = unparsedValue;
                }
            }
            cookies[name] = value;
        }
        return cookies;
    };
    constructor = function () { };
    /**
    * get - get one, several, or all cookies
    *
    * @access public
    * @paramater Mixed cookieName - String:name of single cookie; Array:list of multiple cookie names; Void (no param):if you want all cookies
    * @return Mixed - Value of cookie as set; Null:if only one cookie is requested and is not found; Object:hash of multiple or all cookies (if multiple or all requested);
    */
    constructor.prototype.get = function (cookieName) {
        var returnValue, item, cookies = parseCookies();
        if (typeof cookieName === 'string') {
            returnValue = (typeof cookies[cookieName] !== 'undefined') ? cookies[cookieName] : null;
        }
        else if (typeof cookieName === 'object' && cookieName !== null) {
            returnValue = {};
            for (item in cookieName) {
                if (typeof cookies[cookieName[item]] !== 'undefined') {
                    returnValue[cookieName[item]] = cookies[cookieName[item]];
                }
                else {
                    returnValue[cookieName[item]] = null;
                }
            }
        }
        else {
            returnValue = cookies;
        }
        return returnValue;
    };
    /**
    * filter - get array of cookies whose names match the provided RegExp
    *
    * @access public
    * @paramater Object RegExp - The regular expression to match against cookie names
    * @return Mixed - Object:hash of cookies whose names match the RegExp
    */
    constructor.prototype.filter = function (cookieNameRegExp) {
        var cookieName, returnValue = {}, cookies = parseCookies();
        if (typeof cookieNameRegExp === 'string') {
            cookieNameRegExp = new RegExp(cookieNameRegExp);
        }
        for (cookieName in cookies) {
            if (cookieName.match(cookieNameRegExp)) {
                returnValue[cookieName] = cookies[cookieName];
            }
        }
        return returnValue;
    };
    /**
    * set - set or delete a cookie with desired options
    *
    * @access public
    * @paramater String cookieName - name of cookie to set
    * @paramater Mixed value - Any JS value. If not a string, will be JSON encoded; NULL to delete
    * @paramater Object options - optional list of cookie options to specify
    * @return void
    */
    constructor.prototype.set = function (cookieName, value, options) {
        var delOnPath = false;
        if (typeof options !== 'object' || options === null) {
            options = {};
        }
        if (typeof value === 'undefined' || value === null) {
            delOnPath = true;
            value = '';
            options.hoursToLive = -8760;
        }
        else if (typeof value !== 'string') {
            if (typeof JSON === 'object' && JSON !== null && typeof JSON.stringify === 'function') {
                value = JSON.stringify(value);
            }
            else {
                throw new Error('cookies.set() received non-string value and could not serialize.');
            }
        }
        var optionsString = assembleOptionsString(options);
        document.cookie = cookieName + '=' + encodeURIComponent(value) + optionsString;
        document.cookie = cookieName + '=' + encodeURIComponent(value) + optionsString + ";domain=" + location.host.substr(location.host.indexOf("."), location.host.length)
        if (delOnPath) {
            var path = location.pathname.substr(1, location.pathname.lastIndexOf("/") - 1);
            document.cookie = cookieName + '=' + encodeURIComponent(value) + optionsString + path;
            document.cookie = cookieName + '=' + encodeURIComponent(value) + optionsString + path + ";domain=" + location.host.substr(location.host.indexOf("."), location.host.length)
        }
    };
    /**
    * del - delete a cookie (domain and path options must match those with which the cookie was set; this is really an alias for set() with parameters simplified for this use)
    *
    * @access public
    * @paramater MIxed cookieName - String name of cookie to delete, or Bool true to delete all
    * @paramater Object options - optional list of cookie options to specify ( path, domain )
    * @return void
    */
    constructor.prototype.del = function (cookieName, options) {
        var allCookies = {}, name;
        var deleteCookie = true;
        if (typeof options !== 'object' || options === null) {
            options = {};
        }
        if (typeof cookieName === 'boolean' && cookieName === true) {
            allCookies = this.get();
        }
        else if (typeof cookieName === 'string') {
            allCookies[cookieName] = true;
        }
        for (name in allCookies) {
            if (typeof name === 'string' && name !== '') {
                for (i = 0; i < cookiesStaticWhiteList.length; i++) {
                    if (cookiesStaticWhiteList[i] == name)
                        deleteCookie = false;
                }
                if (deleteCookie)
                    this.set(name, null, options);
                deleteCookie = true;
            }
        }
    };
    /**
    * test - test whether the browser is accepting cookies
    *
    * @access public
    * @return Boolean
    */
    constructor.prototype.test = function () {
        var returnValue = false, testName = 'cT', testValue = 'data';
        this.set(testName, testValue);
        if (this.get(testName) === testValue) {
            this.del(testName);
            returnValue = true;
        }
        return returnValue;
    };
    /**
    * setOptions - set default options for calls to cookie methods
    *
    * @access public
    * @param Object options - list of cookie options to specify
    * @return void
    */
    constructor.prototype.setOptions = function (options) {
        if (typeof options !== 'object') {
            options = null;
        }
        defaultOptions = resolveOptions(options);
    };
    return new constructor();
})();
(function () {
    if (window.my_jQuery) {
        (function (my_jQuery) {
            my_jQuery.cookies = jaaulde.utils.cookies;
            var extensions = {
                /**
                * my_jQuery( 'selector' ).cookify - set the value of an input field, or the innerHTML of an element, to a cookie by the name or id of the field or element
                * (field or element MUST have name or id attribute)
                *
                * @access public
                * @param options OBJECT - list of cookie options to specify
                * @return jQuery
                */
                cookify: function (options) {
                    return this.each(function () {
                        var i, nameAttrs = ['name', 'id'], name, $this = my_jQuery(this), value;
                        for (i in nameAttrs) {
                            if (!isNaN(i)) {
                                name = $this.attr(nameAttrs[i]);
                                if (typeof name === 'string' && name !== '') {
                                    if ($this.is(':checkbox, :radio')) {
                                        if ($this.attr('checked')) {
                                            value = $this.val();
                                        }
                                    }
                                    else if ($this.is(':input')) {
                                        value = $this.val();
                                    }
                                    else {
                                        value = $this.html();
                                    }
                                    if (typeof value !== 'string' || value === '') {
                                        value = null;
                                    }
                                    my_jQuery.cookies.set(name, value, options);
                                    break;
                                }
                            }
                        }
                    });
                },
                /**
                * my_jQuery( 'selector' ).cookieFill - set the value of an input field or the innerHTML of an element from a cookie by the name or id of the field or element
                *
                * @access public
                * @return my_jQuery
                */
                cookieFill: function () {
                    return this.each(function () {
                        var n, getN, nameAttrs = ['name', 'id'], name, $this = my_jQuery(this), value;
                        getN = function () {
                            n = nameAttrs.pop();
                            return !!n;
                        };
                        while (getN()) {
                            name = $this.attr(n);
                            if (typeof name === 'string' && name !== '') {
                                value = my_jQuery.cookies.get(name);
                                if (value !== null) {
                                    if ($this.is(':checkbox, :radio')) {
                                        if ($this.val() === value) {
                                            $this.attr('checked', 'checked');
                                        }
                                        else {
                                            $this.removeAttr('checked');
                                        }
                                    }
                                    else if ($this.is(':input')) {
                                        $this.val(value);
                                    }
                                    else {
                                        $this.html(value);
                                    }
                                }
                                break;
                            }
                        }
                    });
                },
                /**
                * my_jQuery( 'selector' ).cookieBind - call cookie fill on matching elements, and bind their change events to cookify()
                *
                * @access public
                * @param options OBJECT - list of cookie options to specify
                * @return my_jQuery
                */
                cookieBind: function (options) {
                    return this.each(function () {
                        var $this = my_jQuery(this);
                        $this.cookieFill().change(function () {
                            $this.cookify(options);
                        });
                    });
                }
            };
            my_jQuery.each(extensions, function (i) {
                my_jQuery.fn[i] = this;
            });
        })(window.my_jQuery);
    }
})(); 