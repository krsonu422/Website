$(document).ready(function(){


	
/*	$("#rating_num div").bind(clickHandler,function() {
		unLockFrame();
		$("#rating_num div").removeClass("ratingg");
		$(this).addClass("ratingg");
		if($("#rating_num div").hasClass("ratingg")){
			$("#nextBtn").bind("click");
		}
		else{
			$("#nextBtn").unbind("click");
		}
	}); */
	
	
	/*popup jquery*/
/*	$("#sup_popup1").bind(clickHandler,function(){
		$("#sup_popup1_text").show();
	});	 
				 
	$(".sup_popup23").bind(clickHandler,function(){
		$("#sup_popup23_text").show();
	});	 
				 
	$(".sup_popup4").bind(clickHandler,function(){
		$("#sup_popup4_text").show();
	});	 	 
				
	$(".sup_popup5").bind(clickHandler,function(){
		$("#sup_popup5_text").show();
	});	 */	
				
/*	$(".ref3_2").bind(clickHandler,function(){
		$("#ref3_2_text").show();
	});*/

/*	$(".sup1_ch4_1to3").bind(clickHandler,function(){
		$("#ref4_1_text").show();
	});		
			
	$(".switches_refpopup").bind(clickHandler,function(){
		$("#switches_refpopup_text").show();
	});	*/		
				
	/*$(".switch_ref4_2").bind(clickHandler,function(){
		$("#switch_ref4_2_text").show();
	});	*/		
		
/*	$(".summary_ref").bind(clickHandler,function(){
		$("#summary_ref_text").show();
	});	
				
	$("#ad_event").bind(clickHandler,function(){
		$("#summary_events_popup").show();
	});	
				
	$(".adevent_ref").bind(clickHandler,function(){
		$("#adevent_ref_text").show();
	});	*/
	
	

	
				
	$(".sup_popup_close").bind(clickHandler,function(){
		$("#sup_popup1_text, #sup_popup23_text, #sup_popup4_text, #sup_popup5_text, #ref3_2_text, #ref4_1_text, #switches_refpopup_text, #switch_ref4_2_text, #summary_ref_text, #summary_events_popup").hide();
	});		
				
	$(".sup_popup_close1").bind(clickHandler,function(){
		$("#adevent_ref_text").hide();
						
	});
				
			
			/*4_1 popups*/	
				
		/*	$("#slow_clock, #slow_switch_text").bind(clickHandler,function(){
				$("#switch_popup4_1").show();
				$("#slow_switch_text").addClass("active");
				$("#fast_switch_text").removeClass("active");
				$(".slow_switch_heading1, #slow_switch_table").css("display","block");
				$(".fast_switch_heading1, #fast_switch_table").css("display","none");
				});		
			
			$("#fast_clock, #fast_switch_text").bind(clickHandler,function(){
				$("#switch_popup4_1").show();
				$("#slow_switch_text").removeClass("active");
				$("#fast_switch_text").addClass("active");
				$(".slow_switch_heading1, #slow_switch_table").css("display","none");
				$(".fast_switch_heading1, #fast_switch_table").css("display","block");
				});	
		    
			$(".close_btn").bind("click",function(){
				$("#switch_popup4_1").hide();
				});	*/
				 
			/*4_1 popups ends*/	
		 /*4_2 popups*/
			
			$("#switch_btn").bind("click",function(){
					$("#switch_popup4_2").show();
				
				});
				
				
				$(".close_btn").bind("click",function(){
				$("#switch_popup4_2").hide();
				});
			
			
			$("#order_btn").bind("click",function(){
					$("#form_popup").show();
				
				});
				
				
				$(".close_btn_popup").bind("click",function(){
					$("#name").val("Name*");
					$("#town").val("Town/City*");
					$("#address1").val("Address 1*");
					$("#country").val("County*");
					$("#address2").val("Address 2");
					$("#postcode").val("Postcode*");
					$("#address3").val("Address 3");
					$("#phone").val("Phone");
					
					$("#form_popup").hide();
					
				});	
				
				
		/*4_2 popups ends*/
		
		
		
		
		
		
			
		
	});