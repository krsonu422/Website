var clickHandler = "touchstart";
$(document).ready(function() {

    $("body").bind('touchmove', function(event) {console.log(12)
        event.preventDefault();
    });

    if ('ontouchstart' in document.documentElement) {
        clickHandler = "touchstart";
    }

$('#input').bind('touchend',function(){
    console.log(45);
    $('#textbox').trigger('focus')
console.log(323);


})
    Astrazeneca_Animation();

    function Astrazeneca_Animation() {


		$("#tab1").delay(100).animate({'opacity':'1'},1,function(){
                        $('#tab1').attr({"class" : "animated zoomIn"});
            });
			
		$("#tab2").delay(300).animate({'opacity':'1'},1,function(){
                        $('#tab2').attr({"class" : "animated zoomIn"});
            });
		$("#tab3").delay(500).animate({'opacity':'1'},1,function(){
                        $('#tab3').attr({"class" : "animated zoomIn"});
            });
	$("#tab4").delay(700).animate({'opacity':'1'},1,function(){
                        $('#tab4').attr({"class" : "animated zoomIn"});
            });
	$("#tab5").delay(900).animate({'opacity':'1'},1,function(){
                        $('#tab5').attr({"class" : "animated zoomIn"});
            });
	$("#tab6").delay(1100).animate({'opacity':'1'},1,function(){
                        $('#tab6').attr({"class" : "animated zoomIn"});
            });
	$("#tab7").delay(1300).animate({'opacity':'1'},1,function(){
                        $('#tab7').attr({"class" : "animated zoomIn"});
            });
	 $("#tabs1").delay(100).animate({'opacity':'1'},1,function(){
                        $('#tabs1').attr({"class" : "animated zoomIn"});
            });
			
		$("#tabs2").delay(300).animate({'opacity':'1'},1,function(){
                        $('#tabs2').attr({"class" : "animated zoomIn"});
            });
		$("#tabs3").delay(500).animate({'opacity':'1'},1,function(){
                        $('#tabs3').attr({"class" : "animated zoomIn"});
            });
	$("#tabs4").delay(700).animate({'opacity':'1'},1,function(){
                        $('#tabs4').attr({"class" : "animated zoomIn"});
            });
	$("#tabs5").delay(900).animate({'opacity':'1'},1,function(){
                        $('#tabs5').attr({"class" : "animated zoomIn"});
            });
	$("#tabs6").delay(1100).animate({'opacity':'1'},1,function(){
                        $('#tabs6').attr({"class" : "animated zoomIn"});
            });


		$("#img1").bind(clickHandler, function() {
            $("#mid-img2,#img1-active, #full-profile").show();
        });
		
		
		$("#bottom-link1").bind(clickHandler, function() {
            $("#main,#bottom-link1active,#overlay").show();
			$("#dots_img").hide();
        });
		
        //REFERENCE SEC
        $("#referencebtn").bind(clickHandler, function() {
            $("#referencebtn2,#mask").show();
        });
	}

});
