var clickHandler = "click";
var JSONConfig;
var isIpad = false;
var totalFrames = 0;
var currentFrame = 1;
var SingleCountProgess = 0;
var courseStart = false;
var LoadNextFrame = true;
var ProgreesValue = 0;
var imgCache = {};
var cacheLoadCount = 0;
var cacheSize = 0;
var HTMLPath;
var textBoxTimeOut;

var deviceTypeStorage;
var globalProductClass;
var globalDeviceType;
var globalManufacturerType;
var oldtxt_val;
if ("ontouchstart"in document.documentElement) {
    clickHandler = "touchstart";
}

// $('.frame').css('overflow','scroll');
// $('#container').css('overflow','scroll')
// $('#wrapper').css('overflow','scroll')
// $('body').css('overflow','scroll')

function fullscreen() {
    var isInFullScreen = (document.fullscreenElement && document.fullscreenElement !== null) ||
        (document.webkitFullscreenElement && document.webkitFullscreenElement !== null) ||
        (document.mozFullScreenElement && document.mozFullScreenElement !== null) ||
        (document.msFullscreenElement && document.msFullscreenElement !== null);

    var docElm = document.body;
    if (!isInFullScreen) {
        if (docElm.requestFullscreen) {
            docElm.requestFullscreen();
        } else if (docElm.mozRequestFullScreen) {
            docElm.mozRequestFullScreen();
        } else if (docElm.webkitRequestFullScreen) {
            docElm.webkitRequestFullScreen();
        } else if (docElm.msRequestFullscreen) {
            docElm.msRequestFullscreen();
        }
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
}
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    } else {
        clearTimeout(textBoxTimeOut);
        return true;
    }
}
function launchIntoFullscreen(element) {
    if (element.requestFullscreen) {
        element.requestFullscreen();
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
    } else if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen();
    } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen();
    }
}

$("body").bind('tap', function(event) {
        event.preventDefault();
    });


$(document).ready(function() {
    playerInit();
    $("#home").on(clickHandler, function() {
        showFrame(1);
        $('#textbox').val(1);
    });
    $("#cls").on(clickHandler, function() {
        $("#overlay").hide();
        $("#thumbnailstab").hide();
        $("#top_menu").removeClass("active2");
    });
	$("#cls1").on(clickHandler, function() {
        $("#overlay").hide();
        $("#helpchart").hide();
        $("#top_menu").removeClass("active3");
    });
    $(".slideLink").on(clickHandler, function() {
        if ($(this).attr('path') != '' && $(this).attr('path') != null && $(this).attr('path') != undefined) {
			if($(this).attr('path') == 4) {
				if(typeof storetabnum !== "undefined") {
					storetabnum = 1;
				}
			}
            showFrame($(this).attr('path'));storetabnum = 1;
            $("#overlay").hide();
            $("#thumbnailstab").hide();
            $("#top_menu").removeClass("active2");
        }
    });
    $("#textbox").on('keyup', function() {
        var pageVal = parseInt($(this).val());
        $('.frame').removeClass('animated');
        textBoxTimeOut = setTimeout(function() {
            showFrame(pageVal);
        }, 100);
    })
  

    $("#plus").on('click', function() {$('.frame').css('transform-origin','left top');
        $(this).toggleClass('minus');
        if ($(this).hasClass('minus')) {$('#wrapper').css('overflow','scroll')
            $('.frame').removeClass('pageZoomOut').addClass('animated pageZoomIn');
        } else {$('#wrapper').css('overflow','visible')
            $('.frame').removeClass('pageZoomIn').addClass('animated pageZoomOut');

        }

    });
    $("#full").on(clickHandler, function() {
fullscreen()
        //launchIntoFullscreen(document.documentElement);
    });
    $("#menu2").on(clickHandler, function() {
        $("#top_menu").addClass("active2");
    });
	$("#menu3").on(clickHandler, function() {
        $("#top_menu").addClass("active3");
    });
    $("#menu1").on(clickHandler, function() {
        showFrame(2);
    });
    $("#dots_img").on(clickHandler, function() {
        showFrame(2);
    });

   
    $("#menu2").on('click', function() {
        $("#overlay").fadeIn();
        $("#thumbnailstab").show();
    })
	$("#menu3").on('click', function() {
        $("#overlay").fadeIn();
        $("#helpchart").show();
    })
});




function SwipeController() {
    if ("ontouchstart"in document.documentElement) {
        document.documentElement.style.webkitUserSelect = "none";
        /*document.addEventListener('touchmove', function(e) {
            e.preventDefault();
        }, false);*/
        $("#container").bind("touchstart", function(ev) {
            var e = ev.originalEvent;
            startSwipeX = e.targetTouches[0].pageX;
            startSwipeY = e.targetTouches[0].pageY;
            startSwipeTime = new Date().getTime();
        });
        $("#container").bind("touchmove", function(ev) {
            var e = ev.originalEvent;
            var curX = e.targetTouches[0].pageX - startSwipeX;
            var curY = e.targetTouches[0].pageY - startSwipeY;
            var curTime = new Date().getTime();
            var timeDelta = (curTime - startSwipeTime);
            var sinceLastSwipe = curTime - timeSinceLastSwipe;
            var mag = Math.sqrt((curX * curX) + (curY * curY));
            if (mag > 200 && Math.abs(curY) < 50) {
                if (timeDelta > 50 && timeDelta < 250 && sinceLastSwipe > 1000) {
                    e.preventDefault();
                    startSwipeX = e.targetTouches[0].pageX;
                    startSwipeY = e.targetTouches[0].pageY;
                    startSwipeTime = new Date().getTime();
                    timeSinceLastSwipe = curTime;
                    if (curX < 0 && isNextAvailable) {
                    } else if (curX > 0) {
                    }
                }
            }
        });
    }
}

function playerInit() {
    SwipeController();
    $.ajax({
        url: "config.json",
        dataType: "json",
        success: function(data) {
            $("#loading").fadeOut("slow", function() {
                $(".CoverMask").fadeOut("slow");
            });
            if (typeof data == "string" && window.ActiveXObject) {
                JSONConfig = new ActiveXObject("Microsoft.XMLDOM");
                JSONConfig.async = false;
                JSONConfig.loadJSON(data);
            } else {
                JSONConfig = data;
            }
            loadFrames();
        },
        error: function() {
        }
    });
    var preloadIMG = new Array("body_cover.jpg");
    // pass your all files to get preload
    for (var i = 0; i < preloadIMG.length; i++) {
        cachedImage("external/images/" + preloadIMG[i]);
    }
    pageVal = 0;
    if (LoadNextFrame === true) {
        $("#next").bind(clickHandler, function(e) { storetabnum = 1;
            if ($('#textbox').val() !== '')
                pageVal = parseInt($('#textbox').val());
           
            if (!$(this).hasClass("inactive")) {
                nextFrame();
                if (pageVal != 0) {
                    pageVal++;
                    $('#textbox').val(pageVal);
					 
                }
                //$('#textbox').val(pageVal++);
			
            }
			
        });
    }
    $("#prev").on(clickHandler, function(e) { storetabnum = 1;
        if ($('#textbox').val() !== '')
            pageVal = parseInt($('#textbox').val());

        if (!$(this).hasClass("inactive")) {
            previousFrame();
            if (pageVal != 0) {
                pageVal--;

                $('#textbox').val(pageVal);
            }
        }
    });
}

function cachedImage(uri) {
    cacheSize++;
    var img = imgCache[uri];
    if (!img) {
        img = new Image();
        img.onload = function() {
            cacheLoadCount++;
            //debug(numLoaded);
        }
        img.src = uri;
        imgCache[uri] = img;
    }
    return img;
}

function loadFrames() {
    var i = 1;
    totalFrames = JSONConfig.frames.MaxFrameCount;
    for (i = 1; i <= totalFrames; i++) {
        $(".container").append('<div id="f' + i + '" class="frame"/>');
    }
    loadHtmlContents();
}

function LockFrame() {
    $("#next").addClass('inactive');
}

function unLockFrame() {
    $("#next").removeClass("inactive").addClass('btn_active');
}

function nextFrame() {
    if (parseInt(currentFrame) < parseInt(totalFrames)) {
        $(".CoverMask").show();
        $("#loading").show();
        currentFrame++;
        showFrame(currentFrame);
    }
}

function previousFrame() {
    if (currentFrame > 1) {
        $(".CoverMask,#loading").show();
        currentFrame--;
        showFrame(currentFrame);
    }
}

function showFrame(frameNum) {
	if($('#textbox').val()>=21)
	{
		alert('Only 20 Frames available . Please select within 20 frames !');
		$('#textbox').val(oldtxt_val);
		$('#textbox').focus();
	}
	else if($('#textbox').val()=="")
	{
		$(".CoverMask,#loading").hide();
	}
	else
	{
		oldtxt_val=$('#textbox').val();
		$(".CoverMask,#loading").show();
		currentFrame = parseInt(frameNum);
		loadHtmlContents();
	}
}

function PublicUses() {
    if (currentFrame == 1) {
        $(".controls,#logo1").hide();
        $(".topnavigation").show();
        //$("#prev").addClass("inactive").css("cursor", "default");
    } else if (totalFrames == currentFrame) {
        $("#next").addClass("inactive").css("cursor", "default");
    } else if (currentFrame > 1) {
        $(".controls,#logo1").show();
        $("#prev").removeClass("inactive").css("cursor", "pointer");
        $("#next").removeClass("inactive").css("cursor", "pointer");
    }
    if (JSONConfig.frame[currentFrame].FrameNavigation == true) {
        $("#dots_img,.navigation").show();
    } else {
        $("#dots_img,.navigation").hide();
    }

}

function loadHtmlContents() {
    $('.frame').removeClass('animated');
    HTMLPath = JSONConfig.frames.FrameLocation;
    $.get(HTMLPath + '/' + JSONConfig.frame[currentFrame].FileName, function(data) {
        //$('#f' + currentFrame).append(data).ready(function() { //Preventing multiple time loading of frames
            $('#f' + currentFrame).load(HTMLPath + '/' + JSONConfig.frame[currentFrame].FileName, function() {
                $(".CoverMask").fadeOut(function() {
                    $("#loading").fadeOut();
                });
                $('.frame').hide();
				//Pventing overlapping of virtual layout
				setTimeout(function() {
					$("#f" + currentFrame).fadeIn(250);
				}, 60);
				//Ended
            });
            //After append the html do your stuff here
            PublicUses();
        //}); // Ended preventing multiple time loading of frames
    });

}





function preload(framCounter){
	HTMLPath = JSONConfig.frames.FrameLocation;
    $.get(HTMLPath + '/' + JSONConfig.frame[framCounter].FileName, function(data) {
            $('#f' + framCounter).load(HTMLPath + '/' + JSONConfig.frame[framCounter].FileName, function() {
				$("#prev,#next,#buttons,#dots_img,#home").hide();
				$("#textbox")[0].value=1;
            });
		
    });
}


