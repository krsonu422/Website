var jr; (function($) {
    $.fn.lbSlider = function(options) {
        var options = $.extend({
            leftBtn: '.leftBtn',
            rightBtn: '.rightBtn',
            visible: 3,
            autoPlay: false,
            // true or false
            autoPlayDelay: 10,
            // delay in seconds
            autoPlayDirection: 'right-to-left'//autoplay direction
        }, options);
        var make = function() {
            $(this).css('overflow', 'hidden');

            var thisWidth = $(this).width();
            var mod = thisWidth % options.visible;
            if (mod) {
                $(this).width(thisWidth - mod);
                // to prevent bugs while scrolling to the end of slider
            }

            var el = $(this).children('ul');
            jr=el;
            el.css({
                position: 'relative',
                left: '0'
            });
            var leftBtn = $(options.leftBtn)
              , rightBtn = $(options.rightBtn);
           
            var elWidth = el.width() / options.visible;
            el.children('li').css({
                float: 'left',
                width: elWidth
            });
            var elQuant = el.children('li').length;
            el.width(elWidth * elQuant);
            el.css('left', '-' + elWidth * options.visible + 'px');

            function disableButtons() {
                leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
            }
            function enableButtons() {
                leftBtn.removeClass('inactive');
                rightBtn.removeClass('inactive');
            }

			
			//demo
		
			
			pagenumm = $('#textbox').val();
			if(pagenumm == 20){
				len = 2;
				leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
				
			}else
			if(pagenumm == 19){
				len = 1;
				leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
				
			}else
			if(pagenumm == 18){
				len = 2;
				leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
				
			}else
			if(pagenumm == 17){
				len = 3;
				leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
				
			}else
			if(pagenumm == 16){
				len = 3
				leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
			}else
			if(pagenumm == 15){
				len = 6
				
			}else
			if(pagenumm == 14){
				len = 1;
				leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
				
			}else
			if(pagenumm == 13){
				len = 1;
				leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
				
			}else 
			if(pagenumm == 12){
				len = 20
				
			}else 
				if(pagenumm == 11){
				len = 5
				
			}else 
				if(pagenumm == 10){
				len = 4
				  
			}else 
				if(pagenumm == 9){
				len = 8
				
			}else
				if(pagenumm == 8){
				len = 4
				
			}else
				if(pagenumm == 7){
				len = 1;
				  leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
			}else
				if(pagenumm == 6){
				len = 2;
					  leftBtn.addClass('inactive');
                rightBtn.addClass('inactive');
				
			}else
				if(pagenumm == 5){
				len = 5
				
			}else
				if(pagenumm == 4){
				len = 4
				
			}
			 
len1 = Math.ceil(len/3);
len2 = 600 *len;
$('#sliderimg > div > div > ul').css('width',len2+'px')

console.warn(144)
			variabl1 =  Math.ceil(storetabnum/3);
			if(variabl1 != 1){
							 variabl1 = variabl1  - 1;
							 leftval = variabl1*600 ;
							  leftv = '-'+leftval +'px' ;
				 variabl1 = variabl1  + 1;
				setTimeout(function(){$('#sliderimg > div > div > ul').css('left',leftv);
									
									 $('.sa-left').removeClass('inactive');
									  	  
									  if(variabl1 == len1){
								 $('.sa-right').addClass('inactive')}
									 },500)
					
							 }else{}
			
			
			
            leftBtn.bind(clickHandler, (function(event) {
                event.preventDefault();
				
				
				     if (!$(this).hasClass('inactive')) {
                    //   disableButtons();
                    elWidth = 600;

                    el.animate({
                        left: '+=' + elWidth + 'px'
                    }, 150, function() {
                        elWidth = 760;
                        if ($('.sa-right').hasClass('inactive')) {
                            $('.sa-right').removeClass('inactive');
                        }
                        ;
                        if ($('#sliderimg > div > div > ul').css('left') == '0px') {
                            $('.sa-left').addClass('inactive');
                        }
                      

                    });
                }

                return false;
            }));

            rightBtn.bind(clickHandler, function(event) {
               event.preventDefault();
				  if (!$(this).hasClass('inactive')) {
                    elWidth = 600;
                    //disableButtons();
                    el.animate({
                        left: '-=' + elWidth + 'px'
                    }, 150, function() {
                        elWidth = 760;
                        if ($('.sa-left').hasClass('inactive')) {
                            $('.sa-left').removeClass('inactive');
                        }
                        ;
                        if (!$('#sliderimg > div > div > ul').css('left') == '0px') {
                            $('.sa-left').removeClass('inactive');
                        }
                        if ($('#sliderimg > div > div > ul').css('left') ==  (len1-1)*-600+'px') //-2470px  '-3600px'
                        {
                            $('.sa-right').addClass('inactive');
                        }

                    });
                }
            });

            if (options.autoPlay) {
                function aPlay() {
                    var direction = (options.autoPlayDirection);
                    if (direction === 'left-to-right')
                        leftBtn.click();
                    else if (direction === 'right-to-left')
                        rightBtn.click();
                    else
                        leftBtn.click();
                    delId = setTimeout(aPlay, options.autoPlayDelay * 1000);
                }
                var delId = setTimeout(aPlay, options.autoPlayDelay * 1000);
                el.hover(function() {
                    clearTimeout(delId);
                }, function() {
                    delId = setTimeout(aPlay, options.autoPlayDelay * 1000);
                });
            }
        };
        return this.each(make);
    }
    ;
})(jQuery);